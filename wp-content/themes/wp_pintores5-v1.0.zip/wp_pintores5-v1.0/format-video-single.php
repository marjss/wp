<figure class="entry-thumb">
	<?php ci_embed_video(740, 340, '', 'entry-video'); ?>
</figure>
