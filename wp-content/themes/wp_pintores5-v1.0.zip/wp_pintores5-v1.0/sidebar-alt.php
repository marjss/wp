<div class="<?php ci_e_setting('sidebar_content_cols'); ?> columns sidebar-alt">
	<?php comments_template(); ?>
</div>
